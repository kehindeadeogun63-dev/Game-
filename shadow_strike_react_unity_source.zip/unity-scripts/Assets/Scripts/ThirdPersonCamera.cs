using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 2.8f, 5.2f);
    public float sensitivity = 2.2f;
    public float followSmooth = 12f;
    public float minPitch = -15f;
    public float maxPitch = 65f;

    private float yaw;
    private float pitch = 12f;
    private Vector2 touchLast;
    private bool touchDragging;

    void LateUpdate()
    {
        if (!target) return;

        if (Input.GetMouseButton(1))
        {
            yaw += Input.GetAxis("Mouse X") * sensitivity * 3f;
            pitch -= Input.GetAxis("Mouse Y") * sensitivity * 3f;
        }

        if (Input.GetKey(KeyCode.Q)) yaw -= 90f * Time.deltaTime;
        if (Input.GetKey(KeyCode.E)) yaw += 90f * Time.deltaTime;
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 desiredPosition = target.position + rotation * offset;
        transform.position = Vector3.Lerp(transform.position, desiredPosition, followSmooth * Time.deltaTime);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, followSmooth * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 1.35f);
    }

    // Hook these up to a mobile look-area UI using Pointer Down / Drag / Up events.
    public void BeginTouchLook(Vector2 screenPosition)
    {
        touchLast = screenPosition;
        touchDragging = true;
    }

    public void TouchLook(Vector2 screenPosition)
    {
        if (!touchDragging) return;
        Vector2 delta = screenPosition - touchLast;
        touchLast = screenPosition;
        yaw += delta.x * sensitivity * 0.08f;
        pitch = Mathf.Clamp(pitch - delta.y * sensitivity * 0.08f, minPitch, maxPitch);
    }

    public void EndTouchLook() => touchDragging = false;
}
