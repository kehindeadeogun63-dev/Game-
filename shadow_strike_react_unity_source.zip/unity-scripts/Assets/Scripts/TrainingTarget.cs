using UnityEngine;

public class TrainingTarget : MonoBehaviour
{
    public int health = 1;
    public GameObject hitEffect;
    private bool destroyed;

    public void TakeDamage(int damage)
    {
        if (destroyed) return;
        health -= damage;
        if (health <= 0)
        {
            destroyed = true;
            if (hitEffect) Instantiate(hitEffect, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
