using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameHUD : MonoBehaviour
{
    public ThirdPersonPlayer player;
    public TMP_Text healthText;
    public TMP_Text ammoText;
    public TMP_Text messageText;

    void OnEnable()
    {
        if (!player) return;
        player.OnHealthChanged += UpdateHealth;
        player.OnAmmoChanged += UpdateAmmo;
        player.OnMessage += ShowMessage;
        UpdateHealth(player.Health);
        UpdateAmmo(player.ammo, player.ReserveAmmo);
    }

    void OnDisable()
    {
        if (!player) return;
        player.OnHealthChanged -= UpdateHealth;
        player.OnAmmoChanged -= UpdateAmmo;
        player.OnMessage -= ShowMessage;
    }

    public void UpdateHealth(int health)
    {
        if (healthText) healthText.text = $"HEALTH  {health}";
    }

    public void UpdateAmmo(int ammo, int reserve)
    {
        if (ammoText) ammoText.text = $"AMMO  {ammo} / {reserve}";
    }

    public void ShowMessage(string message)
    {
        if (messageText) messageText.text = message;
    }

    public void FireButton() => player?.Fire();
    public void ReloadButton() => player?.Reload();
    public void JumpButton() => player?.Jump();
}
