using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class ThirdPersonPlayer : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 4f;
    public float sprintSpeed = 7f;
    public float jumpHeight = 1.4f;
    public float gravity = -22f;
    public Transform cameraTransform;

    [Header("Combat")]
    public Camera aimCamera;
    public LayerMask aimMask = ~0;
    public float range = 100f;
    public int magazineSize = 32;
    public int reserveAmmo = 120;
    public float fireCooldown = 0.18f;
    public float reloadSeconds = 1.2f;
    public int ammo { get; private set; }
    public int ReserveAmmo => reserveAmmo;
    public bool IsSprinting { get; private set; }

    private CharacterController controller;
    private Vector3 verticalVelocity;
    private float nextFireTime;
    private bool isReloading;
    private float reloadTimer;
    private Vector2 mobileMoveInput;

    public int Health { get; private set; } = 100;
    public System.Action<int> OnHealthChanged;
    public System.Action<int, int> OnAmmoChanged;
    public System.Action<string> OnMessage;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        ammo = magazineSize;
        if (!aimCamera) aimCamera = Camera.main;
    }

    void Update()
    {
        float x = Input.GetAxisRaw("Horizontal") + mobileMoveInput.x;
        float z = Input.GetAxisRaw("Vertical") + mobileMoveInput.y;
        Vector3 input = new Vector3(x, 0f, z);
        input = Vector3.ClampMagnitude(input, 1f);

        IsSprinting = Input.GetKey(KeyCode.LeftShift) && input.sqrMagnitude > 0.05f;
        float speed = IsSprinting ? sprintSpeed : walkSpeed;

        if (input.sqrMagnitude > 0.01f)
        {
            Vector3 forward = cameraTransform ? cameraTransform.forward : transform.forward;
            Vector3 right = cameraTransform ? cameraTransform.right : transform.right;
            forward.y = 0f; right.y = 0f;
            forward.Normalize(); right.Normalize();
            Vector3 move = forward * input.z + right * input.x;
            controller.Move(move * speed * Time.deltaTime);
            if (move.sqrMagnitude > 0.01f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move), 12f * Time.deltaTime);
        }

        if (controller.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
        if (Input.GetButtonDown("Jump")) Jump();
        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move(verticalVelocity * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.R)) Reload();
        if (Input.GetMouseButton(0) || Input.GetKeyDown(KeyCode.Space)) Fire();

        if (isReloading)
        {
            reloadTimer -= Time.deltaTime;
            if (reloadTimer <= 0f) FinishReload();
        }
    }

    public void SetMoveInput(Vector2 input) => mobileMoveInput = Vector2.ClampMagnitude(input, 1f);

    public void Jump()
    {
        if (controller.isGrounded)
            verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
    }

    public void Fire()
    {
        if (Time.time < nextFireTime || isReloading) return;
        if (ammo <= 0) { OnMessage?.Invoke("Magazine empty. Reload."); return; }
        nextFireTime = Time.time + fireCooldown;
        ammo--;
        OnAmmoChanged?.Invoke(ammo, reserveAmmo);

        if (aimCamera == null) return;
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        if (Physics.Raycast(ray, out RaycastHit hit, range, aimMask, QueryTriggerInteraction.Ignore))
        {
            TrainingTarget target = hit.collider.GetComponentInParent<TrainingTarget>();
            if (target != null) target.TakeDamage(1);
        }
    }

    public void Reload()
    {
        if (isReloading || ammo >= magazineSize || reserveAmmo <= 0) return;
        isReloading = true;
        reloadTimer = reloadSeconds;
        OnMessage?.Invoke("Reloading...");
    }

    private void FinishReload()
    {
        int needed = magazineSize - ammo;
        int amount = Mathf.Min(needed, reserveAmmo);
        ammo += amount;
        reserveAmmo -= amount;
        isReloading = false;
        OnAmmoChanged?.Invoke(ammo, reserveAmmo);
        OnMessage?.Invoke("Reload complete.");
    }

    public void TakeDamage(int amount)
    {
        Health = Mathf.Max(0, Health - amount);
        OnHealthChanged?.Invoke(Health);
        if (Health <= 0) OnMessage?.Invoke("You are down. Restart the scene to try again.");
    }
}
