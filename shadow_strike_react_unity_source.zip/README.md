# Shadow Strike — React + Unity starter

This package contains two separate starter projects:
- `react-game/`: browser-playable 3D third-person training prototype using React + Three.js.
- `unity-scripts/`: C# scripts for building the same kind of third-person prototype in Unity.

This is a starter prototype, not a finished commercial game and not a Free Fire clone. It uses simple placeholder geometry; replace it with properly licensed human character models, animations, sounds, and environment assets for realistic visuals.

## React version
Requirements: Node.js 18+ and npm.

1. Open a terminal in `react-game`.
2. Run `npm install`
3. Run `npm run dev`
4. Open the local address printed by Vite.

Controls:
- WASD / arrow keys: move
- Mouse drag: rotate camera
- Shift: sprint
- Space / Fire button: shoot
- R / Reload button: reload
- On-screen controls are included for touch devices.

## Unity version
Recommended: Unity 2022.3 LTS or newer, using the 3D Core template.

1. Create a new 3D project.
2. Copy the C# scripts from `unity-scripts/Assets/Scripts/` into your project's `Assets/Scripts/`.
3. Create a Capsule named `Player`, add a CharacterController, and attach `ThirdPersonPlayer.cs`.
4. Create a Camera and attach `ThirdPersonCamera.cs`. Assign the Player Transform to `target`.
5. Create a few Capsule or Cylinder objects for targets, add `TrainingTarget.cs` to each, and put them on a layer included in the player's `aimMask`.
6. Add a Canvas with a Text (or TMP Text) and attach `GameHUD.cs` to a suitable manager object. Assign the player reference and optional UI labels.
7. For mobile, add UI buttons and connect their Pointer Down/Pointer Up events to `SetMoveInput` / `SetLookInput` or create joystick controls. The script has keyboard support for desktop testing.

The Unity scripts provide movement, camera follow/look, sprint, jump, hitscan shooting, ammo/reload, and target health. You still need to build a scene, assign references, and add assets.

## Note about realism
Realistic third-person gameplay requires a real 3D character model and compatible walk/run/idle/shoot animations. Use assets you have permission to use. The code cannot automatically include proprietary Free Fire assets.
