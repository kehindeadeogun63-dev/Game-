import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export default function App() {
  const mountRef = useRef(null);
  const gameRef = useRef(null);
  const [health, setHealth] = useState(100);
  const [ammoInitial, setAmmoInitial] = useState(32);
  const [reserveInitial, setReserveInitial] = useState(120);
  const [kills, setKills] = useState(0);
  const [status, setStatus] = useState('READY');
  const [messageInitial, setMessageInitial] = useState('Press Start Mission to deploy.');
  const [sprinting, setSprinting] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#9bb8c7');
    scene.fog = new THREE.Fog('#9bb8c7', 24, 95);

    const camera = new THREE.PerspectiveCamera(65, 1, 0.1, 150);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xddeeff, 0x52644a, 2.0));
    const sun = new THREE.DirectionalLight(0xfff0d2, 3);
    sun.position.set(-12, 24, 10);
    sun.castShadow = true;
    scene.add(sun);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(180, 180),
      new THREE.MeshStandardMaterial({ color: '#728a59', roughness: 1 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Road and roadside strip
    const road = new THREE.Mesh(new THREE.PlaneGeometry(12, 110), new THREE.MeshStandardMaterial({ color: '#555b5c', roughness: 1 }));
    road.rotation.x = -Math.PI / 2;
    road.position.set(0, 0.012, -25);
    scene.add(road);
    for (let z = 20; z > -75; z -= 8) {
      const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 3), new THREE.MeshStandardMaterial({ color: '#e7dfb9' }));
      dash.rotation.x = -Math.PI / 2; dash.position.set(0, 0.025, z); scene.add(dash);
    }

    const makeBuilding = (x, z, w, h, d, color) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color, roughness: 0.9 }));
      mesh.position.set(x, h / 2, z); mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh);
      const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.15, 0.22, d + 0.15), new THREE.MeshStandardMaterial({ color: '#4b514d' }));
      roof.position.set(x, h + 0.1, z); roof.castShadow = true; scene.add(roof);
      for (let yy = 1.3; yy < h - 0.5; yy += 1.5) {
        for (let xx = -w / 2 + 0.65; xx < w / 2 - 0.3; xx += 1.3) {
          const win = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.58, 0.06), new THREE.MeshStandardMaterial({ color: '#243c45', roughness: 0.4 }));
          win.position.set(x + xx, yy, z + d / 2 + 0.035); scene.add(win);
        }
      }
    };
    [
      [-11,-9,5,5,5,'#c2b39a'], [-8,-21,6,7,5,'#9eaaa6'], [12,-12,6,6,6,'#c1bca9'],
      [11,3,5,8,6,'#a4ada5'], [-12,5,5,6,6,'#b7a58d'], [-8,18,6,5,5,'#9baca9'],
      [13,-29,7,9,7,'#b5b9ad'], [-16,-34,6,7,6,'#b8aa91'], [20,-2,5,5,6,'#a5b1aa']
    ].forEach(args => makeBuilding(...args));

    // Low-poly palm trees
    const makePalm = (x, z) => {
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 4.5, 7), new THREE.MeshStandardMaterial({ color: '#735c42' }));
      trunk.position.set(x, 2.25, z); trunk.castShadow = true; scene.add(trunk);
      for (let i = 0; i < 7; i++) {
        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.34, 3.3, 5), new THREE.MeshStandardMaterial({ color: i % 2 ? '#315f3c' : '#477448' }));
        leaf.position.set(x + Math.cos(i * Math.PI * 2 / 7) * 1.25, 4.35, z + Math.sin(i * Math.PI * 2 / 7) * 1.25);
        leaf.rotation.z = -Math.PI / 2 + Math.sin(i) * 0.2;
        leaf.rotation.y = -i * Math.PI * 2 / 7; leaf.castShadow = true; scene.add(leaf);
      }
    };
    [[-19,-15],[-18,8],[19,-20],[22,12],[-22,-38],[18,-45]].forEach(p => makePalm(...p));

    // Human-shaped placeholder player. Replace this group with a licensed animated GLB model for realism.
    const player = new THREE.Group();
    const mat = (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.8 });
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.7, 5, 8), mat('#35483d'));
    torso.position.y = 1.45; torso.castShadow = true; player.add(torso);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12), mat('#b58c6a'));
    head.position.y = 2.18; head.castShadow = true; player.add(head);
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.28, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat('#27362f'));
    helmet.position.y = 2.28; player.add(helmet);
    const legs = [];
    for (const x of [-0.19, 0.19]) {
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.13, 0.62, 4, 8), mat('#27332e'));
      leg.position.set(x, 0.53, 0); leg.castShadow = true; player.add(leg); legs.push(leg);
    }
    for (const x of [-0.48, 0.48]) {
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.56, 4, 8), mat('#b58c6a'));
      arm.position.set(x, 1.45, -0.02); arm.rotation.z = x < 0 ? -0.18 : 0.18; player.add(arm);
    }
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.13, 0.85), mat('#171d1b'));
    gun.position.set(0.36, 1.48, -0.55); player.add(gun);
    player.position.set(0, 0, 7); scene.add(player);

    const targets = [];
    const createTarget = (x, z) => {
      const group = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 0.75, 4, 8), mat('#a84532'));
      body.position.y = 1.1; body.castShadow = true; group.add(body);
      const face = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8), mat('#bd9879'));
      face.position.y = 1.8; group.add(face);
      group.position.set(x, 0, z); scene.add(group);
      targets.push({ group, alive: true });
    };
    [[-5,-19],[4,-25],[10,-10],[-10,-8],[2,-35]].forEach(p => createTarget(...p));

    let yaw = 0, running = false, sprint = false, jumpTime = 0, walkTime = 0;
    const keys = new Set();
    let lastTime = 0, pointer = null;
    const state = { player, camera, scene, renderer, keys, targets, get yaw(){return yaw;}, set yaw(v){yaw=v;}, get running(){return running;}, set running(v){running=v;}, get sprint(){return sprint;}, set sprint(v){sprint=v;}, get ammo(){return ammo;}, set ammo(v){ammo=v;}, get reserve(){return reserve;}, set reserve(v){reserve=v;}, set message(v){setMessage(v);} };
    gameRef.current = state;

    const resize = () => {
      const w = Math.max(320, mount.clientWidth);
      const h = Math.max(280, Math.min(520, w * 0.62));
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(mount);

    const keyDown = e => {
      if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault();
      keys.add(e.key.toLowerCase());
      if (e.key === 'Shift') sprint = true;
      if (e.key.toLowerCase() === 'r') reload();
      if (e.code === 'Space') shoot();
    };
    const keyUp = e => { keys.delete(e.key.toLowerCase()); if (e.key === 'Shift') sprint = false; };
    window.addEventListener('keydown', keyDown);
    window.addEventListener('keyup', keyUp);

    const pointerDown = e => { pointer = { x: e.clientX, y: e.clientY }; renderer.domElement.setPointerCapture?.(e.pointerId); };
    const pointerMove = e => {
      if (!pointer || !running) return;
      yaw -= (e.clientX - pointer.x) * 0.006;
      pointer = { x: e.clientX, y: e.clientY };
    };
    const pointerUp = () => { pointer = null; };
    renderer.domElement.addEventListener('pointerdown', pointerDown);
    renderer.domElement.addEventListener('pointermove', pointerMove);
    renderer.domElement.addEventListener('pointerup', pointerUp);
    renderer.domElement.addEventListener('pointercancel', pointerUp);

    function updateCamera() {
      const offset = new THREE.Vector3(Math.sin(yaw) * 5.2, 3.1, Math.cos(yaw) * 5.2);
      camera.position.copy(player.position).add(offset);
      camera.lookAt(player.position.x, player.position.y + 1.25, player.position.z);
    }
    function reload() {
      if (!running) return;
      const n = Math.min(32 - ammo, reserve);
      if (n <= 0) { setMessage('No reserve ammo left.'); return; }
      ammo += n; reserve -= n; setAmmo(ammo); setReserve(reserve); setMessage('Reloaded.');
    }
    function shoot() {
      if (!running) { setMessage('Start the mission first.'); return; }
      if (ammo <= 0) { setMessage('Magazine empty — reload.'); return; }
      ammo--; setAmmo(ammo);
      const forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
      let best = null, bestDist = Infinity;
      for (const t of targets) {
        if (!t.alive) continue;
        const delta = t.group.position.clone().sub(player.position);
        const dist = delta.length();
        delta.y = 0; delta.normalize();
        if (dist < 34 && delta.dot(forward) > 0.94 && dist < bestDist) { best = t; bestDist = dist; }
      }
      if (best) {
        best.alive = false; best.group.visible = false;
        setKills(k => {
          const next = k + 1;
          if (next === targets.length) setMessage('MISSION COMPLETE — all training targets cleared!');
          else setMessage('Target eliminated!');
          return next;
        });
      } else setMessage('Missed. Rotate the camera and line up a target.');
    }

    let alive = true;
    const animate = time => {
      if (!alive) return;
      const dt = Math.min((time - lastTime) / 1000 || 0, 0.04); lastTime = time;
      if (running) {
        const forward = (keys.has('w') || keys.has('arrowup') ? 1 : 0) - (keys.has('s') || keys.has('arrowdown') ? 1 : 0);
        const side = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
        const speed = sprint ? 7 : 3.7;
        const dx = (-Math.sin(yaw) * forward + Math.cos(yaw) * side) * speed * dt;
        const dz = (-Math.cos(yaw) * forward - Math.sin(yaw) * side) * speed * dt;
        if (forward || side) {
          player.position.x = THREE.MathUtils.clamp(player.position.x + dx, -25, 25);
          player.position.z = THREE.MathUtils.clamp(player.position.z + dz, -55, 24);
          walkTime += dt * (sprint ? 13 : 8);
          legs[0].rotation.x = Math.sin(walkTime) * 0.55;
          legs[1].rotation.x = -Math.sin(walkTime) * 0.55;
          player.rotation.y = Math.atan2(-Math.sin(yaw), -Math.cos(yaw));
        } else { legs.forEach(l => l.rotation.x *= 0.8); }
        if (jumpTime > 0) { jumpTime -= dt; player.position.y = Math.sin((0.35 - jumpTime) / 0.35 * Math.PI) * 1.4; }
        else player.position.y = 0;
      }
      updateCamera();
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    const animationId = requestAnimationFrame(animate);
    state.start = () => { running = true; setStatus('IN GAME'); setMessage('Move around the town and line up the crosshair with a target.'); };
    state.turn = n => { yaw += n; };
    state.shoot = shoot;
    state.reload = reload;
    state.jump = () => { if (running && jumpTime <= 0) jumpTime = 0.35; };
    state.setSprinting = v => { sprint = v; };
    state.stop = () => { running = false; };
    state.cleanup = () => {
      alive = false; cancelAnimationFrame(animationId); ro.disconnect();
      window.removeEventListener('keydown', keyDown); window.removeEventListener('keyup', keyUp);
      renderer.domElement.removeEventListener('pointerdown', pointerDown);
      renderer.domElement.removeEventListener('pointermove', pointerMove);
      renderer.domElement.removeEventListener('pointerup', pointerUp);
      renderer.domElement.removeEventListener('pointercancel', pointerUp);
      renderer.dispose(); mount.removeChild(renderer.domElement);
    };
    // expose UI state setters through the game state
    state.updateHud = updateHud;
    return () => state.cleanup();
  }, []);

  const setMessage = (v) => setMessageState(v);
  const [messageState, setMessageState] = useState('Press Start Mission to deploy.');
  const setAmmo = v => setAmmoState(v);
  const [ammoState, setAmmoState] = useState(32);
  const setReserve = v => setReserveState(v);
  const [reserveState, setReserveState] = useState(120);

  const start = () => { gameRef.current?.start(); setStatus('IN GAME'); setMessageState('Move around the town and line up the crosshair with a target.'); };
  const statusSetter = setStatus;
  const fire = () => gameRef.current?.shoot();
  const reloadBtn = () => gameRef.current?.reload();
  const jump = () => gameRef.current?.jump();
  const turn = n => gameRef.current?.turn(n);
  const moveStart = key => gameRef.current?.keys.add(key);
  const moveStop = key => gameRef.current?.keys.delete(key);

  const HoldButton = ({ keyName, children, label }) => (
    <button aria-label={label} onPointerDown={e => { e.preventDefault(); moveStart(keyName); }} onPointerUp={() => moveStop(keyName)} onPointerLeave={() => moveStop(keyName)} onPointerCancel={() => moveStop(keyName)}>{children}</button>
  );

  return <main className="app">
    <header><div><p className="eyebrow">RIVERSIDE TRAINING GROUNDS</p><h1>SHADOW STRIKE 3D</h1></div><span className="status">{status}</span></header>
    <section className="stats">
      <div><small>HEALTH</small><strong>{health}/100</strong></div>
      <div><small>AMMO</small><strong>{ammoState}/{reserveState}</strong></div>
      <div><small>TARGETS</small><strong>{kills}/5</strong></div>
    </section>
    <div className="game-frame"><div ref={mountRef} className="three-mount" /><div className="crosshair">+</div></div>
    <p className="message">{messageState}</p>
    <section className="controls">
      <div><small>MOVEMENT</small><div className="pad">
        <span/><HoldButton keyName="w" label="Move forward">▲</HoldButton><span/>
        <HoldButton keyName="a" label="Move left">◀</HoldButton><HoldButton keyName="s" label="Move backward">▼</HoldButton><HoldButton keyName="d" label="Move right">▶</HoldButton>
      </div></div>
      <div className="action-column"><small>CAMERA & ACTIONS</small><button onClick={() => turn(-0.22)}>↶ Look left</button><button onClick={() => turn(0.22)}>↷ Look right</button><button className="primary" onClick={fire}>◎ FIRE</button><button onClick={reloadBtn}>↻ RELOAD</button><button onClick={jump}>⬆ JUMP</button><button onClick={() => { const next = !sprinting; setSprinting(next); gameRef.current?.setSprinting(next); }}>⚡ Sprint: {sprinting ? 'ON' : 'OFF'}</button><button className="primary" onClick={start}>▶ START MISSION</button></div>
    </section>
    <footer>Starter prototype: replace the placeholder character with a licensed animated 3D model for realistic human movement.</footer>
  </main>;
}
